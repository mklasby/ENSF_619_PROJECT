package Model.TheatreModel;

public class BuildTicket {
	private Ticket ticket;
	
	public BuildTicket() {             
	}

	public Ticket getTicket() {
		return ticket;
	}

	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	} 
	

}
