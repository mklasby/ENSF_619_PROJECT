package Model.TheatreModel;

public class SelectMovie {

}
