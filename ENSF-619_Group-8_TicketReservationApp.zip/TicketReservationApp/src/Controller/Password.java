package Controller;

public interface Password {
	// public static String PASSWORD = "test";
	// JDBC driver name and database URL
	static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://localhost";
	// ENTER YOUR USERNAME HERE!
	static final String USERNAME = "root";
	// ENTER YOUR PASSWORD HERE!
	static final String PASSWORD = "";

}