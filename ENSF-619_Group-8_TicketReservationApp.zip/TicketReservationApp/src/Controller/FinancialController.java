package Controller;

public class FinancialController {
	public FinancialController() {

	}

	public boolean checkPaymentData(String cardType, int cardNum) {
		return true;

	}

}
